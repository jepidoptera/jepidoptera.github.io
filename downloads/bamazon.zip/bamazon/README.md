# bamazon
node app which "accesses" a fake online store
