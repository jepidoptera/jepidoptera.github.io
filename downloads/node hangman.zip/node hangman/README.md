# node-hangman
A version of hangman implemented in the console using node.

Editable word list - edit words.txt.  One guessable word or phrase on each line.

As yet, no graphics - although 'blessed' module looks very capable of handling that end of things.  May implement that in the future if I feel like it.
